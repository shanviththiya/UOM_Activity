﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Activity_07
{
    public partial class Form1 : Form
    {
        private int isCheck;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] numbers = new int[10] { 5000, 1000, 500, 100, 50, 20, 10, 5, 2, 1 };
            try
            {
                if (int.TryParse(textEnterNo.Text, out isCheck))
                {
                    var getModValue = int.Parse(textEnterNo.Text);
                    dgvResult.Rows.Clear();
                    for (int a = 0; a <= numbers.Length - 1; a++)
                    {
                        var getDivideNo = (getModValue / numbers[a]);
                        getModValue = (getModValue % numbers[a]);

                        dgvResult.Rows.Add(string.Format("{0} / =", numbers[a]), getDivideNo);
                    }
                }
                else
                {
                    MessageBox.Show("entered value is invalid");
                    textEnterNo.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
