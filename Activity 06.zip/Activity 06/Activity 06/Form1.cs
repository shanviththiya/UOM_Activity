﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Activity_06
{
    public partial class Form1 : Form
    {
        private int isCheck;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (int.TryParse(textEnterNo.Text, out isCheck))
                {
                    var getValue = int.Parse(textEnterNo.Text);
                    if (getValue > 0)
                    {
                        if (dgvResult.Rows.Count < 10)
                        {
                            dgvResult.Rows.Add(getValue, "");
                            textEnterNo.Text = "";

                            if (dgvResult.Rows.Count == 10)
                            {
                                MessageBox.Show("You have entered 10 numbers");
                                textEnterNo.Focus();
                                textEnterNo.Text = "";
                            }
                        }
                        else
                        {
                            MessageBox.Show("You can not Enter More than 10 Numbers");
                            textEnterNo.Focus();
                            textEnterNo.Text = "";
                        }
                    }
                    else
                    {
                        MessageBox.Show("you can not Enter Number Less than 1");
                        textEnterNo.Focus();
                        textEnterNo.Text = "";
                    }
                }
                else
                {
                    MessageBox.Show("Entered value is invalid");
                    textEnterNo.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void textEnterNo_TextChanged(object sender, EventArgs e)
        {
        }
    }
}
