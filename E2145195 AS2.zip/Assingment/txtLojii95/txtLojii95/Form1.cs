﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace txtLojii95
{
    public partial class Form1 : Form
    {
        private string input;

        public Form1()
        {
            InitializeComponent();
        }

        private void Encode_25_Click(object sender, EventArgs e)
        {
            string input = Input_95.Text;

            if (isNumber(input))
            {
                int reversedNumber = ReverseAndDoubleNumber(input);

                Output_95.Text = reversedNumber.ToString();
            }
            else
            {
                string encodeSentence = EncodedSentence(input);

                Output_95.Text = encodeSentence;
            }

        }
        private bool isNumber(string input)
        {
            return int.TryParse(input, out _);
        }
        private int ReverseAndDoubleNumber(string input)
        {
            char[]charArray = input.ToCharArray();
            Array.Reverse(charArray);
            string reversedString = new string(charArray);

            int number = int.Parse(reversedString);

            int doubleNumber = number * 2;
            return doubleNumber;
        }

        private string EncodedSentence(String sentence)
        {
            StringBuilder encodedSentence = new StringBuilder();
            foreach (char c in sentence)
            {
                char newChar = c;

                if (c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U' || c == 'a' || c == 'e' || c == 'i' || c == 'i' || c == 'u')
                {
                    switch (c)
                    {
                        case 'A':
                            newChar = 'I';
                            break;
                        case 'E':
                            newChar = 'O';
                            break;
                        case 'I':
                            newChar = 'U';
                            break;
                        case 'O':
                            newChar = 'A';
                            break;
                        case 'U':
                            newChar = 'E';
                            break;
                        case 'a':
                            newChar = 'i';
                            break;
                        case 'e':
                            newChar = 'o';
                            break;
                        case 'i':
                            newChar = 'u';
                            break;
                        case 'o':
                            newChar = 'a';
                            break;
                        case 'u':
                            newChar = 'e';
                            break;

                    }
                }
                else if (c >='A'&& c<='Z')
                {
                    newChar = (char)(c - 1);
                }
                else if (c >= 'a' && c <= 'z')
                {
                    newChar = (char)(c - 1);
                }


                else if (c=='.'||c==','||c=='?')
                {
                    newChar = '&';
                }
                encodedSentence.Append(newChar);
            }
            return encodedSentence.ToString();
        }
    }
}
